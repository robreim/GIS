# notebooks

Student notebooks for the latest version of the Automating GIS processes -course: https://autogis.github.io 
